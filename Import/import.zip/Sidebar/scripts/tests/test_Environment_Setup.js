import $ from "jquery"
window.$ = $;